/*
 * Timer_Driver.c
 *
 *  Created on: Oct 8, 2024
 *      Author: youni
 */

#include "Timer_Driver.h"
#include "ErrorHandler.h"



void GPTIMER_Init(GPTIMR_RegDef_t* port, GPTImer_Config_t config)
{

	(port->TIMx_CR1) &= ~(0x3 << CKD_OFFSET);
	(port->TIMx_CR1) |= (config.CKD << CKD_OFFSET);

	(port->TIMx_CR1) &= ~(0x3 << CMS_OFFSET);
	(port->TIMx_CR1) |= (config.CMS << CMS_OFFSET);

	(port->TIMx_CR1) &= ~(0x1 << DIR_OFFSET);
	(port->TIMx_CR1) |= (config.DIR << DIR_OFFSET);

	(port->TIMx_CR1) &= ~(0x1 << ARPE_OFFSET);
	(port->TIMx_CR1) |= (config.ARPE << ARPE_OFFSET);

	(port->TIMx_CR1) &= ~(0x1 << OPM_OFFSET);
	(port->TIMx_CR1) |= (config.OPM << OPM_OFFSET);

	(port->TIMx_CR1) &= ~(0x1 << UDIS_OFFSET);
	(port->TIMx_CR1) |= (config.UDIS << UDIS_OFFSET);

	(port->TIMx_DIER) &= ~(0x1 << UIE_OFFSET);
	(port->TIMx_DIER) |= (config.UIE << UIE_OFFSET);

	(port->TIMx_CR1) &= ~(0x1 << UDIS_OFFSET);
	(port->TIMx_CR1) |= (config.UDIS << UDIS_OFFSET);


	(port->TIMx_PSC) = config.PSC;
	(port->TIMx_ARR) = config.ARR;

	if(config.UIE)
	{
		EnableorDisableTimerInterrupt(port, ENABLE);
	}
	else
	{
		EnableorDisableTimerInterrupt(port, DISABLE);
	}



}


void TimerClkControl(GPTIMR_RegDef_t* port, uint8_t ENorDis)
{
	if(port==TIM112)
	{
		if (ENorDis == ENABLE)
		{
			GPTIMR_CLK_ENABLE(TIM2_CLK_OFFSET);

		}
		else if (ENorDis == DISABLE)
		{
			GPTIMR_CLK_DISABLE(TIM2_CLK_OFFSET);
		}
	}
	if(port == TIM5)
		{
			if(ENorDis == ENABLE)
			{
				GPTIMR_CLK_ENABLE(TIM5_CLK_OFFSET);

			}
			else if (ENorDis == DISABLE)
			{
				GPTIMR_CLK_DISABLE(TIM5_CLK_OFFSET);
			}
		}
}


void TimerStart(GPTIMR_RegDef_t* port)
{
	(port->TIMx_CR1) |= (ENABLE<<CEN_OFFSET);
}

void TimerStop(GPTIMR_RegDef_t* port)
{
	(port->TIMx_CR1) &= ~(0x1<<CEN_OFFSET);
}

void TimerReset(GPTIMR_RegDef_t* port)
{
	(port->TIMx_CNT) = 0;
}

uint32_t returnTimerVal(GPTIMR_RegDef_t* port)
{
	return (port->TIMx_CNT);
}

uint32_t TimerReturnReloadVal(GPTIMR_RegDef_t* port)
{
	return (port->TIMx_ARR);
}

void EnableorDisableTimerInterrupt(GPTIMR_RegDef_t* port, uint8_t ENorDis)
{
	if (port==TIM112)
	{
		if(ENorDis == ENABLE)
		{
			IRQEnable(TIM2_IRQn);
		}
		else if (ENorDis == DISABLE)
		{
			IRQDisable(TIM2_IRQn);
		}
	}

	if (port==TIM5)
	{
		if(ENorDis == ENABLE)
		{
			IRQEnable(TIM5_IRQn);
		}
		else if(ENorDis == DISABLE)
		{
			IRQDisable(TIM5_IRQn);
		}
	}

}

void enableUIE(GPTIMR_RegDef_t* port)
{
	(port->TIMx_DIER) |= (ENABLE << UIE_OFFSET);
}


void LEDInitTimer2()
{
	GPTImer_Config_t timer= {0};

	timer.ARR = ARR_VAL_TIM2;
//	timer.CKD = tdtstclk_int;
//	timer.CMS = EDGE_ALIGHNED;
//	timer.DIR = TIMER_LOW;
//	timer.MMS = TIMER_LOW;
//	timer.OPM = TIMER_LOW;
//	timer.PSC = TIMER_LOW;
//	timer.UDIS = TIMER_LOW;
	timer.UIE = TIMER_HIGH;

	TimerClkControl(TIM112, ENABLE);
	GPTIMER_Init(TIM112, timer);
}


void LEDStartTimer2()
{
	TimerStart(TIM112);
}


void GTimer_ClearInteruptPending(uint8_t pin, GPTIMR_RegDef_t* tim)
{
	(tim->TIMx_SR) &= ~(0x1 << pin);
}




