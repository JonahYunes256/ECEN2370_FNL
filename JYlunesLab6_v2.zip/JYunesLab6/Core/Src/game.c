/*
 * game.c
 *
 *  Created on: Nov 19, 2024
 *      Author: youni
 */

#include "game.h"

//static EXTI_HandleTypeDef LCDTouchIRQ;
void LCDTouchScreenInterruptGPIOInit(void);
//static STMPE811_TouchData StaticTouchData;
volatile uint8_t start_scrn = 0;

static uint32_t gamestart_time;
static uint32_t gamend;

//static STMPE811_State_t touch_state;
static Block_t block;
static Map_t map;
void game_init()
{

	DisplayInitialScreen();
	gamestart_time = HAL_GetTick();


	//game timer






//	GameOverScreen(5);
	if (start_scrn == 1)
	{

	}
	// make a continuity boolean that will be updated based on if the user lossed or not
	while (1)
	{
//			Move_Block(MOVE_DOWN, &block, &map);
	}

	// game over screen

}



void moveShape(uint8_t direction)
{

//uint32_t time_tick = HAL_GetTick();
    if (Check_Collision(&block, &map, direction) == 0)
    {
    	EraseShape(block);

    	block = Move_Block(direction, &block);

        DrawShape(block);
    }
    if (Check_Collision(&block, &map, direction) == 2)
    {
    	map = Stack_Block(&block, &map);


    	block = Block_Init();
    }
//    if (Check_Collision(&block, &map, direction) == 3)
//    {
//
//    }
}



//int8_t STMPE811_GetTouchSide(STMPE811_TouchData *touchdata)
//{
//	if (touchdata->pressed != STMPE811_State_Pressed)
//	{
//		return -1;
//	}
//
//	if (touchdata->x < (MAP_WIDTH / 2)) {
//		return 0;
//	} else {
//		return 1;
//	}
//}



void determineMoveandMove(uint16_t x)
{
	if (x < 120)
	{
		moveShape(MOVE_LEFT);
	}
	else if (x > 120)
	{
		moveShape(MOVE_RIGHT);
	}
}




void EXTI0_IRQHandler()
{
	HAL_NVIC_DisableIRQ(EXTI0_IRQn);
	HAL_EXTI_ClearPending(EXTI_GPIOA, EXTI_TRIGGER_RISING);
	RotateShape(&block, map);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
}

void TIM2_IRQHandler()
{
//	gamend = HAL_GetTick();
//	uint32_t currenttime = (gamend - gamestart_time)/1000;
	HAL_NVIC_DisableIRQ(TIM2_IRQn);
	IRQClearPending(TIM2_IRQn);
	GTimer_ClearInteruptPending(UIF_BIT_OFFSET, TIM112);
//	block = Move_Block(MOVE_DOWN, &block, &map, currenttime);
	if(endGame(&block, &map))
	{
		GameOverScreen(gamestart_time);
	}
	else{
		moveShape(MOVE_DOWN);
	}
	HAL_NVIC_EnableIRQ(TIM2_IRQn);
}







extern void initialise_monitor_handles(void);


#if COMPILE_TOUCH_FUNCTIONS == 1
static STMPE811_TouchData StaticTouchData;
#if TOUCH_INTERRUPT_ENABLED == 1
static EXTI_HandleTypeDef LCDTouchIRQ;
void LCDTouchScreenInterruptGPIOInit(void);
#endif // TOUCH_INTERRUPT_ENABLED
#endif // COMPILE_TOUCH_FUNCTIONS





//-----------------LCD---------------------------------

//extern void initialise_monitor_handles(void);



void ApplicationInit(void)
{
//	initialise_monitor_handles(); // Allows printf functionality
	InitBtnInterrupt();
    LTCD__Init();
    LTCD_Layer_Init(0);
    LCD_Clear(0,LCD_COLOR_WHITE);

    #if COMPILE_TOUCH_FUNCTIONS == 1
	InitializeLCDTouch();

	// This is the orientation for the board to be direclty up where the buttons are vertically above the screen
	// Top left would be low x value, high y value. Bottom right would be low x value, low y value.
	StaticTouchData.orientation = STMPE811_Orientation_Portrait_2;

	#if TOUCH_INTERRUPT_ENABLED == 1
	LCDTouchScreenInterruptGPIOInit();
	#endif // TOUCH_INTERRUPT_ENABLED

	#endif // COMPILE_TOUCH_FUNCTIONS
}

void LCD_Visual_Demo(void)
{
	visualDemo();
}

#if COMPILE_TOUCH_FUNCTIONS == 1

void LCD_Touch_Polling_Demo(void)
{
	LCD_Clear(0,LCD_COLOR_GREEN);
	while (1) {
		/* If touch pressed */
		if (returnTouchStateAndLocation(&StaticTouchData) == STMPE811_State_Pressed) {
			/* Touch valid */
			printf("\nX: %03d\nY: %03d\n", StaticTouchData.x, StaticTouchData.y);
			LCD_Clear(0, LCD_COLOR_RED);
		} else {
			/* Touch not pressed */
			printf("Not Pressed\n\n");
			LCD_Clear(0, LCD_COLOR_GREEN);
		}
	}
}

// TouchScreen Interrupt
#if TOUCH_INTERRUPT_ENABLED == 1

void LCDTouchScreenInterruptGPIOInit(void)
{
	GPIO_InitTypeDef LCDConfig = {0};
    LCDConfig.Pin = GPIO_PIN_15;
    LCDConfig.Mode = GPIO_MODE_IT_RISING_FALLING;
    LCDConfig.Pull = GPIO_NOPULL;
    LCDConfig.Speed = GPIO_SPEED_FREQ_HIGH;

    // Clock enable
    __HAL_RCC_GPIOA_CLK_ENABLE();

    // GPIO Init
    HAL_GPIO_Init(GPIOA, &LCDConfig);

    // Interrupt Configuration
    HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

	LCDTouchIRQ.Line = EXTI_LINE_15;

}

#define TOUCH_DETECTED_IRQ_STATUS_BIT   (1 << 0)  // Touchscreen detected bitmask

static uint8_t statusFlag;

void EXTI15_10_IRQHandler()
{
	HAL_NVIC_DisableIRQ(EXTI15_10_IRQn); // May consider making this a universial interrupt guard
	bool isTouchDetected = false;

	static uint32_t count;
	count = 0;
	while(count == 0){
		count = STMPE811_Read(STMPE811_FIFO_SIZE);
	}

	// Disable touch interrupt bit on the STMPE811
	uint8_t currentIRQEnables = ReadRegisterFromTouchModule(STMPE811_INT_EN);
	WriteDataToTouchModule(STMPE811_INT_EN, 0x00);

	// Clear the interrupt bit in the STMPE811
	statusFlag = ReadRegisterFromTouchModule(STMPE811_INT_STA);
	uint8_t clearIRQData = (statusFlag | TOUCH_DETECTED_IRQ_STATUS_BIT); // Write one to clear bit
	WriteDataToTouchModule(STMPE811_INT_STA, clearIRQData);

	uint8_t ctrlReg = ReadRegisterFromTouchModule(STMPE811_TSC_CTRL);
	if (ctrlReg & 0x80)
	{
		isTouchDetected = true;
	}

	// Determine if it is pressed or unpressed
	if(isTouchDetected) // Touch has been detected
	{
		//printf("\nPressed");
		// May need to do numerous retries?
		DetermineTouchPosition(&StaticTouchData);
		/* Touch valid */
		//printf("\nX: %03d\nY: %03d \n", StaticTouchData.x, StaticTouchData.y);
//		LCD_Clear(0, LCD_COLOR_RED);
		if (start_scrn == 0)
		{
			block = Block_Init();
			map = DrawMap();
			DrawShape(block);
			LEDInitTimer2();
			LEDStartTimer2();
			start_scrn++;
		}
		if (start_scrn == 1)
		{
			determineMoveandMove(StaticTouchData.x);
		}

	}else{

		/* Touch not pressed */
//		printf("\nNot pressed \n");
//		LCD_Clear(0, LCD_COLOR_GREEN);
	}

	STMPE811_Write(STMPE811_FIFO_STA, 0x01);
	STMPE811_Write(STMPE811_FIFO_STA, 0x00);

	// Re-enable IRQs
    WriteDataToTouchModule(STMPE811_INT_EN, currentIRQEnables);
	HAL_EXTI_ClearPending(&LCDTouchIRQ, EXTI_TRIGGER_RISING_FALLING);

	HAL_NVIC_ClearPendingIRQ(EXTI15_10_IRQn);
	HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

	//Potential ERRATA? Clearing IRQ bit again due to an IRQ being triggered DURING the handling of this IRQ..
	WriteDataToTouchModule(STMPE811_INT_STA, clearIRQData);

}
#endif // TOUCH_INTERRUPT_ENABLED
#endif // COMPILE_TOUCH_FUNCTIONS

void InitBtnInterrupt()
{
	InitBtnInterruptMode();
}



