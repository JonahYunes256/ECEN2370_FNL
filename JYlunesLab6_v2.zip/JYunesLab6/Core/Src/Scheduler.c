/*
 * Scheduler.c
 *
 *  Created on: Sep 10, 2024
 *      Author: youni
 */

#include "Scheduler.h"

static uint32_t scheduledEvents;

void addSchedulerEvent(uint32_t validBit)
{
	scheduledEvents |= validBit;
}

void removeSchedulerEvent(uint32_t validBit)
{
	scheduledEvents &= ~validBit;
}

uint32_t getScheduledEvents()
{
	return scheduledEvents;
}
