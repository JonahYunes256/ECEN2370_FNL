/*
 * Button_Driver.c
 *
 *  Created on: Sep 24, 2024
 *      Author: youni
 */

#include "Button_Driver.h"


void buttonInit()
{
	GPIO_InitTypeDef btn;



	btn.Mode = GPIO_MODE_INPUT;
	btn.Pin = GPIO_PIN_0;
	btn.Speed = GPIO_SPEED_FREQ_VERY_HIGH;


	HAL_GPIO_Init(GPIOA, &btn);
}


uint8_t buttonCheck()
{
	return HAL_GPIO_ReadPin(GPIOA, USER_BUTTON_PIN);
}


void InitBtnInterruptMode()
{
	GPIO_InitTypeDef btnInterrupt;
	__HAL_RCC_GPIOA_CLK_ENABLE();
	btnInterrupt.Mode = GPIO_MODE_IT_RISING;
	btnInterrupt.Pin = GPIO_PIN_0;
	btnInterrupt.Speed = GPIO_SPEED_FREQ_HIGH;

	HAL_GPIO_Init(GPIOA, &btnInterrupt);

	HAL_NVIC_EnableIRQ(EXTI0_IRQn);

}
