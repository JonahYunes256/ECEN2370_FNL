/*
 * Scheduler.h
 *
 *  Created on: Sep 10, 2024
 *      Author: youni
 */

#ifndef SCHEDULER_H_
#define SCHEDULER_H_
#include <stdint.h>

#define LED_TOGGLE_EVENT (1 << 0)
#define LED_DELAY_EVENT (1 << 1)
#define BTN_POLL_EVENT (1 << 2)

uint32_t getScheduledEvents();
void addSchedulerEvent(uint32_t);
void removeSchedulerEvent(uint32_t);



#endif /* SCHEDULER_H_ */
