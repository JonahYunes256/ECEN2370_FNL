/*
 * Timer_Driver.h
 *
 *  Created on: Oct 8, 2024
 *      Author: youni
 */

#ifndef TIMER_DRIVER_H_
#define TIMER_DRIVER_H_
#include "InterruptControl.h"
#include "stm32f4xx_hal.h"
#define ARR_VAL_TIM2 79999999

//timers
#define APB1_BASE_ADSRESS 0x40000000
#define TIM2_BASE_ADDRESS (APB1_BASE_ADSRESS + 0x0000)
#define TIM5_BASE_ADDRESS (APB1_BASE_ADSRESS +  0x0C00)
#define TIM112 ((GPTIMR_RegDef_t*) TIM2_BASE_ADDRESS)
//#define TIM5 ((GPTIMR_RegDef_t*) TIM5_BASE_ADDRESS)
#define TIM2_CLK_OFFSET 0
#define TIM5_CLK_OFFSET 3
#define GPTIMR_CLK_ENABLE(bitOfAPB1LPENR) ((RCC->APB1ENR) |= (1 << bitOfAPB1LPENR))
#define GPTIMR_CLK_DISABLE(bitOfAPB1LPENR) ((RCC->APB1ENR) |= (0 << bitOfAPB1LPENR))
#define UIF_BIT_OFFSET 0



//CKD
#define tdtstclk_int 0x0
#define tdts2tclk_int 0x1
#define tdts4tclk_int 0x2
#define reserved 0x3
#define CKD_OFFSET 8

#define TIMER_HIGH 1
#define TIMER_LOW 0

#define ACTIVE 1
#define NON_ACTIVE 0


//CMS
#define EDGE_ALIGHNED 0x0
#define CENTER_ALIGN_1 0x1
#define CENTER_ALIGN_2 0x2
#define CENTER_ALIGN_3 0x3
#define CMS_OFFSET 5

//DIR
#define DIR_OFFSET 4

//ARPE
#define ARPE_OFFSET 7

//OPM
#define OPM_OFFSET 3

//UDIS
#define UDIS_OFFSET 1

//UIE
#define UIE_OFFSET 0

//CEN
#define CEN_OFFSET 0

typedef struct{

	uint32_t ARR;
	uint32_t MMS; //[2:0]
	uint32_t CKD;
	uint32_t PSC;
	uint32_t CMS;
	uint32_t ARPE;
	uint32_t DIR;
	uint32_t UIE;
	uint32_t UDIS;
	uint32_t OPM;

}GPTImer_Config_t;



typedef struct{
	uint32_t TIMx_CR1;
	uint32_t TIMx_CR2;
	uint32_t TIMx_SMCR;
	uint32_t TIMx_DIER;
	uint32_t TIMx_SR;
	uint32_t TIMx_EGR;
	uint32_t TIMx_CCMR1;
	uint32_t TIMx_CCMR2;
	uint32_t TIMx_CCER;
	uint32_t TIMx_CNT;
	uint32_t TIMx_PSC;
	uint32_t TIMx_ARR;
	uint32_t RESERVED_1;
	uint32_t TIMx_CCR1;
	uint32_t TIMx_CCR2;
	uint32_t TIMx_CCR3;
	uint32_t TIMx_CCR4;
	uint32_t RESERVED_2;
	uint32_t TIMx_DCR;
	uint32_t TIMx_DMAR;
	uint32_t TIMx_OR;
//	uint32_t TIM5_OR;
}GPTIMR_RegDef_t;


void TIMER7_Init();//uses hal

void TimerClkControl(GPTIMR_RegDef_t* port, uint8_t ENorDis);

void TimerStart(GPTIMR_RegDef_t* port);
void TimerStop(GPTIMR_RegDef_t* port);
void TimerReset(GPTIMR_RegDef_t* port);

uint32_t returnTimerVal(GPTIMR_RegDef_t* port);

void EnableorDisableTimerInterrupt(GPTIMR_RegDef_t* port, uint8_t ENorDis);

uint32_t TimerReturnReloadVal(GPTIMR_RegDef_t* port);

void enableUIE(GPTIMR_RegDef_t* port);

void LEDInitTimer2();
void LEDStartTimer2();
void GTimer_ClearInteruptPending(uint8_t pin, GPTIMR_RegDef_t* port);
#endif /* TIMER_DRIVER_H_ */
