/*
 * ErrorHandler.h
 *
 *  Created on: Nov 21, 2024
 *      Author: youni
 */

#ifndef INC_ERRORHANDLER_H_
#define INC_ERRORHANDLER_H_

#include "stm32f4xx_hal.h"


void Error_Handler(void);


#endif /* INC_ERRORHANDLER_H_ */
