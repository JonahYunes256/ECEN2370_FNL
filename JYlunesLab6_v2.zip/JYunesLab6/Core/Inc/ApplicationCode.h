/*
 * ApplicationCode.h
 *
 *  Created on: Sep 10, 2024
 *      Author: youni
 */

#ifndef APPLICATIONCODE_H_
#define APPLICATIONCODE_H_

//#include "STM32F429I.h"
//#include "LED_Driver.h"
//#include "ErrorHandler.h"
//#include "Button_Driver.h"
//#include "Scheduler.h"
//#include "stm32f4xx_hal.h"
//#include "LCD_Driver.h"
//#include "Block_Driver.h"
//#include "game.h"
//
//#include <stdio.h>
//
//
//
//void ApplicationInit(void);
//void LCD_Visual_Demo(void);
//
//#if (COMPILE_TOUCH_FUNCTIONS == 1) && (COMPILE_TOUCH_INTERRUPT_SUPPORT == 0)
//void LCD_Touch_Polling_Demo(void);
//#endif // (COMPILE_TOUCH_FUNCTIONS == 1) && (COMPILE_TOUCH_INTERRUPT_SUPPORT == 0)
//
//
//
//#define MY_NAME_LENGTH 5
//#define DELAY 250000
//#define USE_INTERRUPT_FOR_BUTTON 1
//
//#define DUAL_TIMER_USAGE 1
//
//#define ACTIVE 1
//#define NON_ACTIVE 0
//
//void applicationInit();
//void greenLEDInit();
//void redLEDInit();
//void btnInit();
//void executeButtonPollingRoutine();
//void toggleGreenLED();
//void toggleRedLED();
//void activateGreedLED();
//void activateReddLED();
//void deactivateGreedLED();
//void deactivateReddLED();
//void appDelay(uint32_t);
//void InitBtnInterrupt();
//






#endif /* APPLICATIONCODE_H_ */
