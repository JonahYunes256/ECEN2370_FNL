/*
 * InterruptControl.h
 *
 *  Created on: Oct 1, 2024
 *      Author: youni
 */

#ifndef INTERRUPTCONTROL_H_
#define INTERRUPTCONTROL_H_

#include "stm32f4xx_hal.h"
#include "Timer_Driver.h"

//interrupt
//interrupt
#define NVIC_ISER0_ADRESS 0xE000E100
#define NVIC_ICER0_ADRESS 0XE000E180
#define NVIC_ISPR0_ADRESS 0XE000E200
#define NVIC_ICPR0_ADRESS 0XE000E280

#define NVIC_ISER1_ADRESS (0xE000E100 +0x4)
#define NVIC_ICER1_ADRESS (0XE000E180 +0x4)
#define NVIC_ISPR1_ADRESS (0XE000E200 +0x4)
#define NVIC_ICPR1_ADRESS (0XE000E280 +0x4)


#define NVIC_ISER0 ((volatile uint32_t*) NVIC_ISER0_ADRESS)
#define NVIC_ICER0 ((volatile uint32_t*) NVIC_ICER0_ADRESS)
#define NVIC_ISPR0 ((volatile uint32_t*) NVIC_ISPR0_ADRESS)
#define NVIC_ICPR0 ((volatile uint32_t*) NVIC_ICPR0_ADRESS)

#define NVIC_ISER1 ((volatile uint32_t*) NVIC_ISER1_ADRESS)
#define NVIC_ICER1 ((volatile uint32_t*) NVIC_ICER1_ADRESS)
#define NVIC_ISPR1 ((volatile uint32_t*) NVIC_ISPR1_ADRESS)
#define NVIC_ICPR1 ((volatile uint32_t*) NVIC_ICPR1_ADRESS)


void IRQEnable(uint8_t IRQ_num);
void IRQDisable(uint8_t IRQ_num);
void IRQClearPending(uint8_t IRQ_num);
void IRQSetPending(uint8_t IRQ_num);

void clearInteruptPending(uint8_t pin);




#endif /* INTERRUPTCONTROL_H_ */
