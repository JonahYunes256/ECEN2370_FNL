/*
 * game.h
 *
 *  Created on: Nov 19, 2024
 *      Author: youni
 */

#ifndef INC_GAME_H_
#define INC_GAME_H_

#include "Block_Driver.h"
#include "stmpe811.h"
#include "Timer_Driver.h"

#define TOUCHED_R 1
#define TOUCH_L 0
#define UNLOVED -1


void game_init();
uint8_t randomNum();
int8_t STMPE811_GetTouchSide(STMPE811_TouchData *data);
void determineMoveandMove(uint16_t x);
void LCDTouchScreenInterruptGPIO_De_Init(void);

//#include "STM32F429I.h"
//#include "LED_Driver.h"
#include "ErrorHandler.h"
#include "Button_Driver.h"
#include "Scheduler.h"
#include "stm32f4xx_hal.h"
#include "LCD_Driver.h"
#include "Block_Driver.h"
#include "game.h"

#include <stdio.h>



void ApplicationInit(void);
void LCD_Visual_Demo(void);

#if (COMPILE_TOUCH_FUNCTIONS == 1) && (COMPILE_TOUCH_INTERRUPT_SUPPORT == 0)
void LCD_Touch_Polling_Demo(void);
#endif // (COMPILE_TOUCH_FUNCTIONS == 1) && (COMPILE_TOUCH_INTERRUPT_SUPPORT == 0)



#define MY_NAME_LENGTH 5
#define DELAY 250000
#define USE_INTERRUPT_FOR_BUTTON 1

#define DUAL_TIMER_USAGE 1

#define ACTIVE 1
#define NON_ACTIVE 0

void applicationInit();
void greenLEDInit();
void redLEDInit();
void btnInit();
void executeButtonPollingRoutine();
void toggleGreenLED();
void toggleRedLED();
void activateGreedLED();
void activateReddLED();
void deactivateGreedLED();
void deactivateReddLED();
void appDelay(uint32_t);
void InitBtnInterrupt();

void moveShape(uint8_t direction);








#endif /* INC_GAME_H_ */
