/*
 * Block_Driver.h
 *
 *  Created on: Nov 14, 2024
 *      Author: youni
 */

#ifndef INC_BLOCK_DRIVER_H_
#define INC_BLOCK_DRIVER_H_
#include "stm32f4xx_hal.h"
#include "LCD_Driver.h"
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>

#define BLOCK_WIDTH 21
#define MAP_HEIGHT 282
#define RIGHT_EDGE 215
#define LEFT_EDGE 6
#define BOTTOM_EDGE 278
#define EDGE_VLAUE 4
#define MAP_WIDTH 230


//#define BLOCK_WIDTH 23
//#define EDGE_WIDTH 4
//#define MAP_HEIGHT 309
//#define MAP_DIFFERENCE 11

//#define BLOCK_START_X 75
//#define BLOCK_START_Y 17
//#define RIGHT_EDGE 213
//#define LEFT_EDGE 6
//#define BOTTOM_ROW 293



#define SHAPE_COUNT 7
//#define BLOCK_I_POS[2]
//#define BLOCK_O_POS[1]
//#define BLOCK_J_POS[4]
//#define BLOCK_L_POS[4]
//#define BLOCK_S_POS[2]
//#define BLOCK_Z_POS[2]
//#define BLOCK_T_POS[4]

#define ASCII_A_HEX 0x41
#define ASCII_B_HEX 0x42
#define ASCII_C_HEX 0x43
#define ASCII_D_HEX 0x44
#define ASCII_E_HEX 0x45
#define ASCII_F_HEX 0x46
#define ASCII_G_HEX 0x47
#define ASCII_H_HEX 0x48
#define ASCII_I_HEX 0x49
#define ASCII_J_HEX 0x4A
#define ASCII_K_HEX 0x4B
#define ASCII_L_HEX 0x4C
#define ASCII_M_HEX 0x4D
#define ASCII_N_HEX 0x4E
#define ASCII_O_HEX 0x4F
#define ASCII_P_HEX 0x50
#define ASCII_Q_HEX 0x51
#define ASCII_R_HEX 0x52
#define ASCII_S_HEX 0x53
#define ASCII_T_HEX 0x54
#define ASCII_U_HEX 0x55
#define ASCII_V_HEX 0x56
#define ASCII_W_HEX 0x57
#define ASCII_X_HEX 0x58
#define ASCII_Y_HEX 0x59
#define ASCII_Z_HEX 0x5A

#define MOVE_DOWN 1
#define MOVE_UP -1
#define MOVE_LEFT 0
#define MOVE_RIGHT 2

#define POPULATED 1
#define EMPTY 0


#define N 4

#define I 0
#define J 1
#define L 2
#define O 3
#define S 4
#define T 5
#define Z 6



typedef struct {
	uint16_t color;
	uint8_t logical_shape[4][4];
	uint16_t x[4];
	uint16_t y[4];
	char shape;
}Block_t;


typedef struct {

	uint16_t block_colors[11][14];
	uint16_t block_pos[11][14];
	uint16_t block_logical_pos[11][14];
	uint16_t grid_pos_x[11];
	uint16_t grid_pos_y[14];
}Map_t;



void map_init();
void creat_block();
void drop_block();
void sleep_block();
void rotate_block();
void move_block();
void DrawTetrisGrid();
void DrawBlock(uint16_t x, uint16_t y, uint16_t size, uint16_t color);
void DrawTetrisShapes();
void DrawPlayButton();
void DisplayInitialScreen();
void DrawTetrisLogo();
void clear_screen();




Map_t DrawMap();
void DrawIShape(uint8_t pos);


Block_t Block_Init();
Map_t Stack_Block(Block_t *block, Map_t *map);

//void Stack_Block(Block_t block, Map_t *map);
//make a block apear on the n the top part of the map to drop
void DrawShape(Block_t block);

void DrawShapeLikeAMan(Block_t block);

void EraseShape(Block_t block);

int Check_Collision(Block_t *block, Map_t *map, uint8_t direction);
Block_t Move_Block(uint8_t direction, Block_t *block);
//void Move_Block(uint8_t direction, Block_t *block, Map_t *map);

void Rotate_Block(Block_t *block, Map_t map);

int endGame(Block_t *block, Map_t *map);
void RotateShape(Block_t *block, Map_t map); // this work better (hopefully haha)

void rotate90(uint8_t mat[N][N]);

void DrawGrid();


// ---------- game over --------
uint8_t* numberToArray(uint32_t number, size_t* size);
char* digitsToChars(const uint8_t* digits, size_t size);

void UpdateMap(Map_t map);

void GameOverScreen(uint32_t time);

#endif /* INC_BLOCK_DRIVER_H_ */
