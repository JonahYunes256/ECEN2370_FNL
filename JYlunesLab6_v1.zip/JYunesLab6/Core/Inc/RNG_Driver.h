/*
 * RNG_Driver.h
 *
 *  Created on: Nov 24, 2024
 *      Author: youni
 */

#ifndef INC_RNG_DRIVER_H_
#define INC_RNG_DRIVER_H_



void MX_RNG_Init(void);


#endif /* INC_RNG_DRIVER_H_ */
