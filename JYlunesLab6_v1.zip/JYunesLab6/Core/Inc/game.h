/*
 * game.h
 *
 *  Created on: Nov 19, 2024
 *      Author: youni
 */

#ifndef INC_GAME_H_
#define INC_GAME_H_

#include "Block_Driver.h"
#include "stmpe811.h"


#define TOUCHED_R 1
#define TOUCH_L 0
#define UNLOVED -1


void game_init();
uint8_t randomNum();
int8_t STMPE811_GetTouchSide(STMPE811_TouchData *data);
void determineMoveandMove(uint16_t x);


#endif /* INC_GAME_H_ */
