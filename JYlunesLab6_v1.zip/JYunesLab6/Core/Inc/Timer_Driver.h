/*
 * Timer_Driver.h
 *
 *  Created on: Oct 8, 2024
 *      Author: youni
 */

#ifndef TIMER_DRIVER_H_
#define TIMER_DRIVER_H_
#include "InterruptControl.h"

//CKD
#define tdtstclk_int 0x0
#define tdts2tclk_int 0x1
#define tdts4tclk_int 0x2
#define reserved 0x3
#define CKD_OFFSET 8

#define TIMER_HIGH 1
#define TIMER_LOW 0

#define ACTIVE 1
#define NON_ACTIVE 0


//CMS
#define EDGE_ALIGHNED 0x0
#define CENTER_ALIGN_1 0x1
#define CENTER_ALIGN_2 0x2
#define CENTER_ALIGN_3 0x3
#define CMS_OFFSET 5

//DIR
#define DIR_OFFSET 4

//ARPE
#define ARPE_OFFSET 7

//OPM
#define OPM_OFFSET 3

//UDIS
#define UDIS_OFFSET 1

//UIE
#define UIE_OFFSET 0

//CEN
#define CEN_OFFSET 0

typedef struct{

	uint32_t ARR;
	uint32_t MMS; //[2:0]
	uint32_t CKD;
	uint32_t PSC;
	uint32_t CMS;
	uint32_t ARPE;
	uint32_t DIR;
	uint32_t UIE;
	uint32_t UDIS;
	uint32_t OPM;

}GPTImer_Config_t;


void TIMER7_Init();//uses hal
//
//void TimerClkControl(GPTIMR_RegDef_t* port, uint8_t ENorDis);
//
//void TimerStart(GPTIMR_RegDef_t* port);
//void TimerStop(GPTIMR_RegDef_t* port);
//void TimerReset(GPTIMR_RegDef_t* port);
//
//uint32_t returnTimerVal(GPTIMR_RegDef_t* port);
//
//void EnableorDisableTimerInterrupt(GPTIMR_RegDef_t* port, uint8_t ENorDis);
//
//uint32_t TimerReturnReloadVal(GPTIMR_RegDef_t* port);
//
//void enableUIE(GPTIMR_RegDef_t* port);


#endif /* TIMER_DRIVER_H_ */
