/*
 * Button_Driver.h
 *
 *  Created on: Sep 24, 2024
 *      Author: youni
 */

#ifndef BUTTON_DRIVER_H_
#define BUTTON_DRIVER_H_

#include "stm32f4xx_hal.h"
#include "InterruptControl.h"

#define EXTI0_IRQ_NUMBER 6

#define USER_BUTTON_PIN 0
#define USER_BUTTON_PORT GPIOA
#define BUTTON_PRESS 1
#define BUTTON_UNPRESS 0



void buttonInit();
uint8_t buttonCheck();

void InitBtnInterruptMode();

#endif /* BUTTON_DRIVER_H_ */
