/*
 * RNG_Driver.c
 *
 *  Created on: Nov 24, 2024
 *      Author: youni
 */

#include "RNG_Driver.h"
#include "stm32f4xx_hal.h"
#include "ErrorHandler.h"


RNG_HandleTypeDef hrng;

void MX_RNG_Init(void)
{

  /* USER CODE BEGIN RNG_Init 0 */

  /* USER CODE END RNG_Init 0 */

  /* USER CODE BEGIN RNG_Init 1 */

  /* USER CODE END RNG_Init 1 */
  hrng.Instance = RNG;
  if (HAL_RNG_Init(&hrng) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RNG_Init 2 */

  /* USER CODE END RNG_Init 2 */

}
