/*
 * ErrorHandler.c
 *
 *  Created on: Nov 21, 2024
 *      Author: youni
 */


#include "ErrorHandler.h"

void Error_Handler(void)
{
	__disable_irq();
  while (1)
  {
  }
}
