/*
 * game.c
 *
 *  Created on: Nov 19, 2024
 *      Author: youni
 */

#include "game.h"


static STMPE811_State_t touch_state;
static Block_t block;
static Map_t map;
void game_init()
{
	DisplayInitialScreen();
	HAL_Delay(1000);



	block = Block_Init(T);
	map = DrawMap();
	//game timer
	uint32_t gamestart_time = HAL_GetTick();

//	touch_state = STMPE811_Init();

//	STMPE811_t touch_data = {0};

//	touch_state = STMPE811_ReadTouch(&touch_data);

//	while(touch_status == STMPE811_State_Released)
//	{
//
//	}
	DrawShape(block);
//	HAL_Delay(1000);
//	Move_Block(MOVE_DOWN, &block, map);
//	HAL_Delay(1000);
//	Move_Block(MOVE_DOWN, &block, map);
//	HAL_Delay(1000);
//	Move_Block(MOVE_DOWN, &block, map);
//	HAL_Delay(1000);
//	Move_Block(MOVE_DOWN, &block, map);
//	HAL_Delay(1000);
	//	HAL_Delay(1000);
//	Move_Block(MOVE_DOWN, &block, map);
//	HAL_Delay(1000);
//	Move_Block(MOVE_DOWN, &block, map);
//	HAL_Delay(1000);
//	Move_Block(MOVE_RIGHT, &block, map);
//	HAL_Delay(1000);
//	Move_Block(MOVE_RIGHT, &block, map);
//	HAL_Delay(1000);
//	Move_Block(MOVE_RIGHT, &block, map);
//	HAL_Delay(1000);
//	Move_Block(MOVE_RIGHT, &block, map);

//	GameOverScreen(5);

	// make a continuity boolean that will be updated based on if the user lossed or not
	while (1)
	{
			HAL_Delay(1000);
			Move_Block(MOVE_DOWN, &block, map);
//			HAL_Delay(1000);
//			RotateShape(&block, map);
	}

	// game over screen

}



int8_t STMPE811_GetTouchSide(STMPE811_TouchData *touchdata)
{
	if (touchdata->pressed != STMPE811_State_Pressed)
	{
		return -1;
	}

	if (touchdata->x < (MAP_WIDTH / 2)) {
		return 0;
	} else {
		return 1;
	}
}



void I2C3_EV_IRQHandler()
{
	//----------touch--------------
	STMPE811_t touch_data = {0};

//	touch_state = STMPE811_ReadTouch(&touch_data);

	DisplayInitialScreen();

	HAL_Delay(500);
	if(touch_state == 0)
	{
		//move block left
	}
	if(touch_state == 1)
	{

	}

	//_____________________________
}

void determineMoveandMove(uint16_t x)
{
	if (x < 120)
	{
		Move_Block(MOVE_LEFT, &block, map);
	}
	else if (x > 120)
	{
		Move_Block(MOVE_RIGHT, &block, map);
	}
}


//void EXTI0_IRQHandler()
//{
////	IRQDisable(EXTI0_IRQ_NUMBER);
////	Rotate_Block()
////	IRQClearPending(EXTI0_IRQ_NUMBER);
////	EXTI_ClearInteruptPending(USER_BUTTON_PIN);
////	IRQEnable(EXTI0_IRQ_NUMBER);
//}

void EXTI0_IRQHandler()
{
	HAL_NVIC_DisableIRQ(EXTI0_IRQn);
	HAL_EXTI_ClearPending(EXTI_GPIOA, EXTI_TRIGGER_RISING);
	RotateShape(&block, map);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
}
