/*
 * InterruptControl.c
 *
 *  Created on: Oct 1, 2024
 *      Author: youni
 */

#include "InterruptControl.h"


void IRQEnable(uint8_t IRQ_num)
{
	if(IRQ_num < 32)
	{
//		(SYSCFG->SYSCFG_EXTICR[0]);
		*NVIC_ISER0 |= (0x1 << IRQ_num);
	}
	if (IRQ_num >= 32)
	{
		*NVIC_ISER1 |= (0x1 << (IRQ_num%32));
	}
}

void IRQDisable(uint8_t IRQ_num)
{
	if(IRQ_num < 32)
	{
		(*NVIC_ICER0 |= (0x1 << IRQ_num));
	}
	if (IRQ_num >= 32)
	{
		(*NVIC_ICER1 |= (0x1 << (IRQ_num%32)));
	}
}

void IRQClearPending(uint8_t IRQ_num)
{
	if(IRQ_num < 32)
	{
		(*NVIC_ICPR0 |= (0x1 << IRQ_num));
	}
	if (IRQ_num >= 32)
	{
		(*NVIC_ICPR1 |= (0x1 << (IRQ_num%32)));
	}
}

void IRQSetPending(uint8_t IRQ_num)
{
	if(IRQ_num < 32)
	{
		(*NVIC_ISPR0 |= (0x1 << IRQ_num));
	}
	if (IRQ_num >= 32)
	{
		(*NVIC_ISPR1 |= (0x1 << (IRQ_num%32)));
	}
}

void clearInteruptPending(uint8_t pin)
{
	(EXTI->PR) &= ~(0x1 << pin);
}


