/*
 * Timer_Driver.c
 *
 *  Created on: Oct 8, 2024
 *      Author: youni
 */

#include "Timer_Driver.h"
#include "ErrorHandler.h"




//void TimerClkControl(GPTIMR_RegDef_t* port, uint8_t ENorDis)
//{
//	if(port==TIM2)
//	{
//		if (ENorDis == ENABLE)
//		{
//			GPTIMR_CLK_ENABLE(TIM2_CLK_OFFSET);
//
//		}
//		else if (ENorDis == DISABLE)
//		{
//			GPTIMR_CLK_DISABLE(TIM2_CLK_OFFSET);
//		}
//	}
//	if(port == TIM5)
//		{
//			if(ENorDis == ENABLE)
//			{
//				GPTIMR_CLK_ENABLE(TIM5_CLK_OFFSET);
//
//			}
//			else if (ENorDis == DISABLE)
//			{
//				GPTIMR_CLK_DISABLE(TIM5_CLK_OFFSET);
//			}
//		}
//}
//
//
//void TimerStart(GPTIMR_RegDef_t* port)
//{
//	(port->TIMx_CR1) |= (ENABLE<<CEN_OFFSET);
//}
//
//void TimerStop(GPTIMR_RegDef_t* port)
//{
//	(port->TIMx_CR1) &= ~(0x1<<CEN_OFFSET);
//}
//
//void TimerReset(GPTIMR_RegDef_t* port)
//{
//	(port->TIMx_CNT) = 0;
//}
//
//uint32_t returnTimerVal(GPTIMR_RegDef_t* port)
//{
//	return (port->TIMx_CNT);
//}
//
//uint32_t TimerReturnReloadVal(GPTIMR_RegDef_t* port)
//{
//	return (port->TIMx_ARR);
//}
//
//void EnableorDisableTimerInterrupt(GPTIMR_RegDef_t* port, uint8_t ENorDis)
//{
//	if (port==TIM2)
//	{
//		if(ENorDis == ENABLE)
//		{
//			IRQEnable(TIM2_IRQ_NUM);
//		}
//		else if (ENorDis == DISABLE)
//		{
//			IRQDisable(TIM2_IRQ_NUM);
//		}
//	}
//
//	if (port==TIM5)
//	{
//		if(ENorDis == ENABLE)
//		{
//			IRQEnable(TIM5_IRQ_NUM);
//		}
//		else if(ENorDis == DISABLE)
//		{
//			IRQDisable(TIM5_IRQ_NUM);
//		}
//	}
//
//}
//
//void enableUIE(GPTIMR_RegDef_t* port)
//{
//	(port->TIMx_DIER) |= (ENABLE << UIE_OFFSET);
//}







