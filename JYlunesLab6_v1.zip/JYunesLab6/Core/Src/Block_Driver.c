/*
 * Block_Driver.c
 *
 *  Created on: Nov 14, 2024
 *      Author: youni
 */


#include "Block_Driver.h"


// Clear the screen to black
//void LCD_Clear(uint8_t LayerIndex, uint16_t Color) {
//    for (uint16_t y = 0; y < LCD_PIXEL_HEIGHT; y++) {
//        LCD_Draw_Horizantal_Line(0, y, LCD_PIXEL_WIDTH, Color);
//    }
//}


void clear_screen()
{
	LCD_Clear(0,LCD_COLOR_WHITE);
}


void DrawBlock(uint16_t x, uint16_t y, uint16_t size, uint16_t color)
{
    for (uint16_t i = 0; i < size; i++)
    {
        LCD_Draw_Horizantal_Line(x, y + i, size, color);
    }
}


void DrawTetrisShapes() {
    uint16_t block_size = 20;
    uint16_t spacing = 15;
    uint16_t x_offset = (LCD_PIXEL_WIDTH - (7 * (block_size * 4 + spacing))) / 2;

    //1bc1

    // "I" shape (cyan) //fb3
    for (int i = 0; i < 4; i++) {
        DrawBlock(55, 210 + i*block_size, block_size, LCD_COLOR_CYAN);
    }

    // "J" shape (blue)
    x_offset += block_size * 4 + spacing;
    for (int i = 0; i < 3; i++) {
        DrawBlock(80 + i * block_size, 210 + block_size, block_size, LCD_COLOR_BLUE);
    }
    DrawBlock(80, 210, block_size, LCD_COLOR_BLUE);

    // "L" shape (yellow)
    x_offset += block_size * 4 + spacing;
    for (int i = 0; i < 3; i++) {
        DrawBlock(145 + i * block_size, 210 + block_size, block_size, LCD_COLOR_YELLOW);
    }
    DrawBlock(105 + block_size * 2, 250, block_size, LCD_COLOR_YELLOW);

    // "O" shape (grn)
    x_offset += block_size * 4 + spacing;
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            DrawBlock(x_offset + i * block_size, 75 + j * block_size, block_size, LCD_COLOR_GREEN);
        }
    }

    // "S" shape (green)
    x_offset += block_size * 4 + spacing;
    DrawBlock(x_offset, 75 + block_size, block_size, LCD_COLOR_MAGENTA);
    DrawBlock(x_offset + block_size, 75 + block_size, block_size, LCD_COLOR_MAGENTA);
    DrawBlock(x_offset + block_size, 75, block_size, LCD_COLOR_MAGENTA);
    DrawBlock(x_offset + block_size * 2, 75, block_size, LCD_COLOR_MAGENTA);

    // "T" shape (purple)
    x_offset += block_size * 4 + spacing;
    for (int i = 0; i < 3; i++) {
        DrawBlock(5 + i * block_size, 75, block_size, LCD_COLOR_RED);
    }
    DrawBlock(5 + block_size, 75 + block_size, block_size, LCD_COLOR_RED);

    // "Z" shape (red)
    x_offset += block_size * 4 + spacing;
    DrawBlock(x_offset, 75, block_size, LCD_COLOR_WHITE);
    DrawBlock(x_offset + block_size, 75, block_size, LCD_COLOR_WHITE);
    DrawBlock(x_offset + block_size, 75 + block_size, block_size, LCD_COLOR_WHITE);
    DrawBlock(x_offset + block_size * 2, 75 + block_size, block_size, LCD_COLOR_WHITE);
}



// Centered Play Button
void DrawPlayButton() {
    uint16_t button_height = 40;
    uint16_t button_y = LCD_PIXEL_HEIGHT - 60;

    for (int i = 0; i < button_height; i++) {
        //LCD_Draw_Horizantal_Line(button_x, button_y + i, button_height, LCD_COLOR_BLUE);
        LCD_Draw_Horizantal_Line(80, 146 + i, 80, LCD_COLOR_BLUE);

    }

    LCD_SetTextColor(LCD_COLOR_WHITE);
    LCD_SetFont(&Font12x12);
    LCD_DisplayChar(87, button_y - 100, 0x50);
    LCD_SetTextColor(LCD_COLOR_RED);
    LCD_DisplayChar(105, button_y - 100, 0x4c);
    LCD_SetTextColor(LCD_COLOR_YELLOW);
    LCD_DisplayChar(123, button_y - 100, 0x41);
    LCD_SetTextColor(LCD_COLOR_GREEN);
    LCD_DisplayChar(141, button_y - 100, 0x59);
}


void DrawTetrisLogo()
{
	uint16_t distance_from_scrn = 18;
	LCD_SetTextColor(LCD_COLOR_MAGENTA);
	LCD_SetFont(&Font16x24);
	LCD_DisplayChar(distance_from_scrn, 30, ASCII_T_HEX);
	LCD_SetTextColor(LCD_COLOR_RED);
	LCD_DisplayChar(3*distance_from_scrn, 30, ASCII_E_HEX);
	LCD_SetTextColor(LCD_COLOR_YELLOW);
	LCD_DisplayChar(5*distance_from_scrn, 30, ASCII_T_HEX);
	LCD_SetTextColor(LCD_COLOR_GREEN);
	LCD_DisplayChar(7*distance_from_scrn, 30, ASCII_R_HEX);
	LCD_SetTextColor(LCD_COLOR_ORANGE);
	LCD_DisplayChar(9*distance_from_scrn, 30, ASCII_I_HEX);
	LCD_SetTextColor(LCD_COLOR_BLUE);
	LCD_DisplayChar(11*distance_from_scrn, 30, ASCII_S_HEX);
}

// Initial Screen
void DisplayInitialScreen() {
    LCD_Clear(0, LCD_COLOR_BLACK);
    DrawTetrisShapes();
    DrawPlayButton();
    DrawTetrisLogo();
}

//_______________________________________________________________________








//=========================game==========================================
Map_t DrawMap()
{
	LCD_Clear(0, LCD_COLOR_BLACK);
    uint16_t v_length = LCD_PIXEL_WIDTH;

    uint16_t edge_x = 0;
    uint16_t edge_y = 0;

    Map_t map;


    // Draw vertical grid lines (inside the map)
    for (int i = EDGE_VLAUE; i <= v_length - EDGE_VLAUE; i += BLOCK_WIDTH) {
        LCD_Draw_Vertical_Line(i, edge_y, MAP_HEIGHT + BLOCK_WIDTH, LCD_COLOR_WHITE);
    }

    // Draw left and right edge lines
    for (int i = 0; i < EDGE_VLAUE; i++)
    {
        // Left edge
        LCD_Draw_Vertical_Line(i, edge_y, MAP_HEIGHT + BLOCK_WIDTH, LCD_COLOR_WHITE);

        // Right edge
        LCD_Draw_Vertical_Line(v_length - EDGE_VLAUE + i, edge_y, MAP_HEIGHT + BLOCK_WIDTH, LCD_COLOR_WHITE);
    }

    // Draw horizontal grid lines (inside the map)
    for (int i = EDGE_VLAUE; i <= MAP_HEIGHT + BLOCK_WIDTH - EDGE_VLAUE; i += BLOCK_WIDTH)
    {
        LCD_Draw_Horizantal_Line(edge_x, i, v_length, LCD_COLOR_WHITE);
    }

    // Draw top and bottom edge lines
    for (int i = 0; i < EDGE_VLAUE; i++)
    {
        // Top edge
        LCD_Draw_Horizantal_Line(edge_x, i, v_length, LCD_COLOR_WHITE);

        // Bottom edge
        LCD_Draw_Horizantal_Line(edge_x, MAP_HEIGHT + BLOCK_WIDTH - EDGE_VLAUE + i, v_length, LCD_COLOR_WHITE);
    }


    uint16_t distance_from_scrn = 12;
    	LCD_SetTextColor(LCD_COLOR_ORANGE);
    	LCD_SetFont(&Font12x12);
    	LCD_DisplayChar(distance_from_scrn, 305, ASCII_P_HEX);
    	LCD_SetTextColor(LCD_COLOR_ORANGE);
    	LCD_DisplayChar(3*distance_from_scrn, 305, ASCII_O_HEX);
    	LCD_SetTextColor(LCD_COLOR_ORANGE);
    	LCD_DisplayChar(5*distance_from_scrn, 305, ASCII_T_HEX);
    	LCD_SetTextColor(LCD_COLOR_ORANGE);
    	LCD_DisplayChar(7*distance_from_scrn, 305, ASCII_A_HEX);
    	LCD_SetTextColor(LCD_COLOR_ORANGE);
    	LCD_DisplayChar(9*distance_from_scrn, 305, ASCII_T_HEX);
    	LCD_SetTextColor(LCD_COLOR_ORANGE);
    	LCD_DisplayChar(11*distance_from_scrn, 305, ASCII_O_HEX);
    	LCD_SetTextColor(LCD_COLOR_WHITE);
    	LCD_DisplayChar(13*distance_from_scrn, 305, ASCII_I_HEX);
    	LCD_SetTextColor(LCD_COLOR_WHITE);
    	LCD_DisplayChar(15*distance_from_scrn, 305, ASCII_N_HEX);
    	LCD_SetTextColor(LCD_COLOR_WHITE);
    	LCD_DisplayChar(17*distance_from_scrn, 305, ASCII_C_HEX);
    	LCD_SetTextColor(LCD_COLOR_WHITE);
    	LCD_DisplayChar(19*distance_from_scrn, 305, '.');

    	for (int i = 0; i < 11; i++)
    	{
    		map.grid_pos_x[i] = i*BLOCK_WIDTH + 5;
    	}
    	for (int j = 0; j < 13; j++)
    	{
    		map.grid_pos_y[j] = j*BLOCK_WIDTH + 5;
    	}

    	return map;
}



void DrawGrid()
{
	//mght need to clear
    uint16_t v_length = LCD_PIXEL_WIDTH;

    uint16_t edge_x = 0;
    uint16_t edge_y = 0;

    Map_t map;


    // Draw vertical grid lines (inside the map)
    for (int i = EDGE_VLAUE; i <= v_length - EDGE_VLAUE; i += BLOCK_WIDTH) {
        LCD_Draw_Vertical_Line(i, edge_y, MAP_HEIGHT + BLOCK_WIDTH, LCD_COLOR_WHITE);
    }

    // Draw left and right edge lines
    for (int i = 0; i < EDGE_VLAUE; i++)
    {
        // Left edge
        LCD_Draw_Vertical_Line(i, edge_y, MAP_HEIGHT + BLOCK_WIDTH, LCD_COLOR_WHITE);

        // Right edge
        LCD_Draw_Vertical_Line(v_length - EDGE_VLAUE + i, edge_y, MAP_HEIGHT + BLOCK_WIDTH, LCD_COLOR_WHITE);
    }

    // Draw horizontal grid lines (inside the map)
    for (int i = EDGE_VLAUE; i <= MAP_HEIGHT + BLOCK_WIDTH - EDGE_VLAUE; i += BLOCK_WIDTH)
    {
        LCD_Draw_Horizantal_Line(edge_x, i, v_length, LCD_COLOR_WHITE);
    }

    // Draw top and bottom edge lines
    for (int i = 0; i < EDGE_VLAUE; i++)
    {
        // Top edge
        LCD_Draw_Horizantal_Line(edge_x, i, v_length, LCD_COLOR_WHITE);

        // Bottom edge
        LCD_Draw_Horizantal_Line(edge_x, MAP_HEIGHT + BLOCK_WIDTH - EDGE_VLAUE + i, v_length, LCD_COLOR_WHITE);
    }

    uint16_t distance_from_scrn = 12;
    	LCD_SetTextColor(LCD_COLOR_ORANGE);
    	LCD_SetFont(&Font12x12);
    	LCD_DisplayChar(distance_from_scrn, 305, ASCII_P_HEX);
    	LCD_SetTextColor(LCD_COLOR_ORANGE);
    	LCD_DisplayChar(3*distance_from_scrn, 305, ASCII_O_HEX);
    	LCD_SetTextColor(LCD_COLOR_ORANGE);
    	LCD_DisplayChar(5*distance_from_scrn, 305, ASCII_T_HEX);
    	LCD_SetTextColor(LCD_COLOR_ORANGE);
    	LCD_DisplayChar(7*distance_from_scrn, 305, ASCII_A_HEX);
    	LCD_SetTextColor(LCD_COLOR_ORANGE);
    	LCD_DisplayChar(9*distance_from_scrn, 305, ASCII_T_HEX);
    	LCD_SetTextColor(LCD_COLOR_ORANGE);
    	LCD_DisplayChar(11*distance_from_scrn, 305, ASCII_O_HEX);
    	LCD_SetTextColor(LCD_COLOR_WHITE);
    	LCD_DisplayChar(13*distance_from_scrn, 305, ASCII_I_HEX);
    	LCD_SetTextColor(LCD_COLOR_WHITE);
    	LCD_DisplayChar(15*distance_from_scrn, 305, ASCII_N_HEX);
    	LCD_SetTextColor(LCD_COLOR_WHITE);
    	LCD_DisplayChar(17*distance_from_scrn, 305, ASCII_C_HEX);
    	LCD_SetTextColor(LCD_COLOR_WHITE);
    	LCD_DisplayChar(19*distance_from_scrn, 305, '.');
}
Block_t Block_Init(uint8_t RNG_output)
{
	Block_t block;
	char shapes[] = {'I', 'J', 'L', 'O', 'S', 'T', 'Z'};
	uint16_t colors[] = {LCD_COLOR_BLUE, LCD_COLOR_RED, LCD_COLOR_MAGENTA, LCD_COLOR_GREEN,
			LCD_COLOR_CYAN, LCD_COLOR_YELLOW, LCD_COLOR_ORANGE};
	//checking for which block is picked
	for (int i = 0; i < 7; i++)
	{
		if (RNG_output == i)
		{
			block.shape = shapes[i];
			block.color = colors[i];
		}
	}



	if (block.shape == 'I')
	{
		uint16_t logi_sh[4][4] =
								{{0,0,0,1},
								{0,0,0,1},
								{0,0,0,1},
								{0,0,0,1}};

		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				block.logical_shape[i][j] = logi_sh[j][i];
			}
		}


		for (int i = 1; i <= 4; i++)
		{
			block.y[i - 1] = EDGE_VLAUE + (i - 1)*BLOCK_WIDTH + 1;
			block.x[i - 1] = EDGE_VLAUE + (i - 2)*BLOCK_WIDTH + 1 + 3*BLOCK_WIDTH;
		}

	}
	else if (block.shape == 'J')
	{
		uint16_t logi_sh[4][4] =
								{{0,0,0,0},
								{0,0,0,1},
								{0,0,0,1},
								{0,0,1,1}};
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				block.logical_shape[i][j] = logi_sh[j][i];
			}
		}


		for (int i = 1; i <= 4; i++)
		{
			block.y[i - 1] = EDGE_VLAUE + (i - 1)*BLOCK_WIDTH+ 1;
			block.x[i - 1] = EDGE_VLAUE + (i - 2)*BLOCK_WIDTH+ 1+ 3*BLOCK_WIDTH;
		}
	}
	else if (block.shape == 'L')
	{
		uint16_t logi_sh[4][4] =
								{{1,0,0,0},
								{1,1,1,0},
								{0,0,0,0},
								{0,0,0,0}};
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				block.logical_shape[i][j] = logi_sh[j][i];
			}
		}


		for (int i = 1; i <= 4; i++)
		{
			block.y[i - 1] = EDGE_VLAUE + (i - 1)*BLOCK_WIDTH+ 1;
			block.x[i - 1] = EDGE_VLAUE + (i - 2)*BLOCK_WIDTH+ 1+ 3*BLOCK_WIDTH;
		}
	}
	else if (block.shape == 'O')
	{
		uint16_t logi_sh[4][4] =
								{{1,1,0,0},
								{1,1,0,0},
								{0,0,0,0},
								{0,0,0,0}};


		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				block.logical_shape[i][j] = logi_sh[j][i];
			}
		}


		for (int i = 1; i <= 4; i++)
		{
			block.y[i - 1] = EDGE_VLAUE + (i - 1)*BLOCK_WIDTH+ 1;
			block.x[i - 1] = EDGE_VLAUE + (i - 2)*BLOCK_WIDTH+ 1+ 3*BLOCK_WIDTH;
		}

	}
	else if (block.shape == 'S')
	{
		uint16_t logi_sh[4][4] =
								{{0,1,1,0},
								{1,1,0,0},
								{0,0,0,0},
								{0,0,0,0}};


		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				block.logical_shape[i][j] = logi_sh[j][i];
			}
		}


		for (int i = 1; i <= 4; i++)
		{
			block.y[i - 1] = EDGE_VLAUE + (i - 1)*BLOCK_WIDTH+ 1;
			block.x[i - 1] = EDGE_VLAUE + (i - 2)*BLOCK_WIDTH+ 1+ 3*BLOCK_WIDTH;
		}

	}
	else if (block.shape == 'T')
	{
		uint16_t logi_sh[4][4] =
								{{0,1,0,0},
								{1,1,1,0},
								{0,0,0,0},
								{0,0,0,0}};
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				block.logical_shape[i][j] = logi_sh[j][i];
			}
		}


		for (int i = 1; i <= 4; i++)
		{
			block.y[i - 1] = EDGE_VLAUE + (i - 1)*BLOCK_WIDTH+ 1;
			block.x[i - 1] = EDGE_VLAUE + (i - 1)*BLOCK_WIDTH+ 1 + 3*BLOCK_WIDTH;
		}
	}
	else if (block.shape == 'Z')
	{
		uint16_t logi_sh[4][4] =
								{{1,1,0,0},
								{0,1,1,0},
								{0,0,0,0},
								{0,0,0,0}};
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				block.logical_shape[i][j] = logi_sh[j][i];
			}
		}


		for (int i = 1; i <= 4; i++)
		{
			block.y[i - 1] = EDGE_VLAUE + (i - 1)*BLOCK_WIDTH+ 1;
			block.x[i - 1] = EDGE_VLAUE + (i - 2)*BLOCK_WIDTH+ 1+ 3*BLOCK_WIDTH;
		}

	}
	return block;
}




void EraseShape(Block_t block)
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (block.logical_shape[i][j])
			{
				DrawBlock(block.x[i], block.y[j], BLOCK_WIDTH, LCD_COLOR_BLACK);
			}
		}
	}
//	// ****maybe take this off****
	DrawGrid();
}







int is_valid_position(uint8_t direction, Block_t block, Map_t map)
{

	uint8_t max_x_index = 0;
	uint8_t max_x_val = 0;
	uint8_t max_y_index = 0;
	uint8_t max_y_val = 0;
	uint8_t min_x_index = INT8_MAX;
	uint8_t min_x_val = 0;

	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 4; j++)
		{
			if(block.logical_shape[i][j])
			{
				if(i > max_x_index)
				{
					max_x_index = i;
				}
				if (j>max_y_index)
				{
					max_y_index = j;
				}
				if(i < min_x_index)
				{
					min_x_index = i;
				}
			}
		}
	}
	max_x_val = block.x[max_x_index];
	min_x_val = block.x[min_x_index];
	max_y_val = block.x[max_y_index];
	if(direction == MOVE_RIGHT)
	{
		if(max_x_val != RIGHT_EDGE)
		{
			return 0; // right edge
		}
	}
	if(direction == MOVE_LEFT)
	{
		if(min_x_val != LEFT_EDGE)
		{
			return 0;
		}
	}
	if(direction == MOVE_DOWN)
	{
		if(max_y_val != BOTTOM_EDGE)
		{
			return 0;
		}
	}

	return 1;

//    uint16_t i;
//    for (i = 0; i < 4; i++)
//    {
//        uint16_t xPos = block.x[i];
//        uint16_t yPos = block.y[i];
//
//        if (xPos < 0 || xPos >= BLOCK_WIDTH || yPos < 0 || yPos >= HIEGHT_OF_MAP || map.block_pos[yPos][xPos] != 0)
//        {
//            return 0;
//        }
//    }
//    return 1;
}



void Move_Block(uint8_t direction, Block_t *block, Map_t map)
{
    Block_t tempBlock = *block;
    for (int i = 0; i < 4; i++)
    {
        if (direction == MOVE_LEFT)
        {
            tempBlock.x[i] -= BLOCK_WIDTH;
        }
        else if (direction == MOVE_RIGHT)
        {
            tempBlock.x[i] += BLOCK_WIDTH;
        }
        else if (direction == MOVE_DOWN)
        {
            tempBlock.y[i] += BLOCK_WIDTH;
        }
        else if (direction == MOVE_UP)
        {
            tempBlock.y[i] -= BLOCK_WIDTH;
        }
    }

    if (Check_Collision(*block, map, direction) == 0)
    {
        EraseShape(*block);

        *block = tempBlock;

        DrawShape(*block);
    }
    if (Check_Collision(*block, map, direction) == 2)
    {
    	*block = Stack_Block(*block, map, 1);
    }
}


Block_t Stack_Block(Block_t block, Map_t map, uint8_t RNG_output)
{

	for (int a = 0; a < 4; a++)
	{
		for (int b = 0; b < 4; b++)
		{
			if (block.logical_shape[a][b])
			{
				for (int i = 0; i < 11; i++)
				{
					for(int j = 0; j < 13; j++)
					{
						if (block.x[a] == map.grid_pos_x[i] && block.y[b] == map.grid_pos_y[j])
						{
							map.block_logical_pos[i][j] = POPULATED;
						}
					}
				}
			}
		}
	}


	Block_t tempBlock = Block_Init(RNG_output);

	map = UpdateMap(map); // might cause some updating problems

	DrawShape(tempBlock);

	return tempBlock;
}



void DrawShape(Block_t block)
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (block.logical_shape[i][j])
			{
				DrawBlock(block.x[i], block.y[j], BLOCK_WIDTH - 2, block.color);
			}
		}
	}
}

Map_t UpdateMap(Map_t map)
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (map.block_logical_pos[i][j])
			{
				DrawBlock(map.grid_pos_x[i], map.grid_pos_y[j], BLOCK_WIDTH - 2, LCD_COLOR_RED); // if you want colors on the stacked block make a color update funtion
			}
		}
	}
}


int Check_Collision(Block_t block, Map_t map, uint8_t direction)
{
	uint8_t y_max = 0;
	uint8_t y_min = 3;

	uint8_t x_max = 0;
	uint8_t x_min = 3;
    for (int i = 0; i < 4; i++)
    {
    	for (int j = 0; j < 4; j++)
    	{
    		if (block.logical_shape[i][j])
    		{
        		uint16_t x = block.x[i];
    			uint16_t y = block.y[j];

    			if (direction == MOVE_LEFT || direction == MOVE_RIGHT)
    			{
        			if (x < LEFT_EDGE || x >= RIGHT_EDGE + 1 || y < 0)
        			{
        				return 1; // dont move
        			}
        			if (map.block_pos[y / BLOCK_WIDTH][x / BLOCK_WIDTH] == POPULATED) //need to check if this work
        			{
        				return 1; // dont move
        			}
    			}


    			if (direction == MOVE_DOWN)
    			{
    				if (y > BOTTOM_EDGE - BLOCK_WIDTH)
    				{
    					return 2;
    				}
    				for (int a = 0; a < 11; a++)
    				{
        				for (int b = 0; b < 13; b++)
        				{
        					if(block.logical_shape[a][b])
        					{
        						if(b > y_max)
        						{
        							y_max = b;
        							x_max = a;
        						}
        						if (b < y_min)
        						{
        							y_min  = b;
        							x_min = a;
        						}

        					}
        				}
    				}

    				for (int s = 0; s < 11; s++)
    				{
    					for (int w = 0; w < 13; w++)
    					{
    						if (map.block_logical_pos[s][w])
    						{
        	    				if (map.grid_pos_x[s] == block.x[x_max] && map.grid_pos_y[w] == block.y[y_max])
        	    				{
        	    					return 2; // there s a bloc under t so stac please
        	    				}
    						}
    					}
    				}
    			}
    		}
    	}
    }
    // No collision detected
    return 0;
}





void rotate90(uint8_t mat[N][N])
{
	uint8_t n = N;


    // Perform Transpose
    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            int temp = mat[i][j];
            mat[i][j] = mat[j][i];
            mat[j][i] = temp;
        }
    }

    // Reverse each row
    for (int i = 0; i < n; i++)
    {
        int start = 0, end = n - 1;
        while (start < end)
        {
            int temp = mat[i][start];
            mat[i][start] = mat[i][end];
            mat[i][end] = temp;
            start++;
            end--;
        }
    }
}



void RotateShape(Block_t *block, Map_t map)
{
    Block_t tempBlock = *block;

    int centerX = 0, centerY = 0;

    switch (block->shape)
    {
    case 'I':
        centerX = (block->x[1] + block->x[2]) / 2;
        centerY = (block->y[1] + block->y[2]) / 2;
        break;

    case 'O':
        return;

    case 'T':
        centerX = block->x[1];
        centerY = block->y[1];
        break;

    case 'L':
        centerX = block->x[1];
        centerY = block->y[1];
        break;

    case 'Z':
        centerX = block->x[1];
        centerY = block->y[1];
        break;

    case 'J':
         centerX = block->x[1];
         centerY = block->y[1];
         break;

    case 'S':
         centerX = block->x[1];
         centerY = block->y[1];
        break;

    default:
        return;
    }

//    for (int i = 0; i < 4; i++)
//    {
//        int deltaX = block->x[i] - centerX;
//        int deltaY = block->y[i] - centerY;
//
//        // apply counterclockwise rotation
//        tempBlock.x[i] = deltaY + centerY;
//        tempBlock.y[i] = -deltaX + centerX;
//    }


    uint8_t tempShape[4][4];

    rotate90(tempBlock.logical_shape);

//    i dont think I have to change coordinates right ??



//    if (is_valid_rotation(tempBlock, map))
//    {
        EraseShape(*block);

        *block = tempBlock;

        DrawShape(*block);
//    }
}



int is_valid_rotation(Block_t tempBlock, Map_t map)
{
    for (int i = 0; i < 4; i++)
    {
        if (tempBlock.x[i] < 0 || tempBlock.x[i] >= MAP_WIDTH || tempBlock.y[i] < 0 || tempBlock.y[i] >= MAP_HEIGHT)
        {
            return 0; // Out of bounds
        }

        if (map.block_pos[tempBlock.y[i]][tempBlock.x[i]] == POPULATED)
        {
            return 0; // Collision detected
        }
    }

    return 1; // Valid rotation
}



//------------------------------------------ game over -------------------------------------------

uint8_t* numberToArray(uint32_t number, size_t* size)
{
    // Temporary variable to find the number of digits
    uint32_t temp = number;
    *size = 0;

    // Count the number of digits
    do
    {
        temp /= 10;
        (*size)++;
    } while (temp > 0);

    // Allocate memory for the array
    uint8_t* array = (uint8_t*)malloc(*size * sizeof(uint8_t));
    if (array == NULL)
    {
        // Memory allocation failed
        *size = 0;
        return NULL;
    }

    // Fill the array with digits in reverse order
    for (size_t i = *size; i > 0; i--) {
        array[i - 1] = number % 10;
        number /= 10;
    }

    return array;
}

char* digitsToChars(const uint8_t* digits, size_t size)
{
    // Allocate memory for the char array (including null terminator)
    char* chars = (char*)malloc((size + 1) * sizeof(char));
    if (chars == NULL)
    {
        // Memory allocation failed
        return NULL;
    }

    // Convert each digit to a char
    for (size_t i = 0; i < size; i++)
    {
        chars[i] = digits[i] + '0'; // Convert digit to its ASCII character
    }

    // Null-terminate the string
    chars[size] = '\0';

    return chars;
}



void GameOverScreen(uint32_t time)
{
	LCD_Clear(0, LCD_COLOR_RED);

	//Write game over
	uint16_t distance_from_scrn = 12;
	uint16_t distance_from_scrn_y = 160;
	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_SetFont(&Font12x12);
	LCD_DisplayChar(distance_from_scrn, distance_from_scrn_y, ASCII_G_HEX);
	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_DisplayChar(3*distance_from_scrn, distance_from_scrn_y, ASCII_A_HEX);
	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_DisplayChar(5*distance_from_scrn, distance_from_scrn_y, ASCII_M_HEX);
	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_DisplayChar(7*distance_from_scrn, distance_from_scrn_y, ASCII_E_HEX);


	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_DisplayChar(9*distance_from_scrn, distance_from_scrn_y, ASCII_O_HEX);
	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_DisplayChar(11*distance_from_scrn, distance_from_scrn_y, ASCII_V_HEX);
	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_DisplayChar(13*distance_from_scrn, distance_from_scrn_y, ASCII_E_HEX);
	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_DisplayChar(15*distance_from_scrn, distance_from_scrn_y, ASCII_R_HEX);


	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_DisplayChar(distance_from_scrn, distance_from_scrn_y + 30, ASCII_T_HEX);
	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_DisplayChar(3*distance_from_scrn, distance_from_scrn_y + 30, ASCII_I_HEX);
	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_DisplayChar(5*distance_from_scrn, distance_from_scrn_y + 30, ASCII_M_HEX);
	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_DisplayChar(7*distance_from_scrn, distance_from_scrn_y + 30, ASCII_E_HEX);
	LCD_SetTextColor(LCD_COLOR_WHITE);
	LCD_DisplayChar(9*distance_from_scrn, distance_from_scrn_y + 30, ':');

	size_t siveOfTime = 4;
	uint8_t* numberToArray(time, siveOfTime);
	for (int i = 0; i < 4; i++)
	{

	}

}


